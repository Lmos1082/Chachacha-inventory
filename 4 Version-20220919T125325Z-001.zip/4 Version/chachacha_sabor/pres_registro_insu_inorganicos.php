<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="estilos_formularios.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body bgcolor="#000">
<?php
   
    echo"<center>";
    echo"<h1>Registre el insumo inorganico<h1>";
    echo"<br>";
    echo"<br>";
    echo"<br>";
    echo"<br>";
    echo"<br>";
 
    echo"<form name='registro_menu' action='neg_dat_registro_insu_inorganicos.php' method='POST' required>";
    echo"Nombre:<input name='Nombre' type='text'><br/>";
    echo"categorias:<select name='categorias'>";
    echo"<option>categorias</option>";
    

   /////////////
   include("conexion.php");

   $sql = "SELECT * FROM categorias";
if(!$result = $db->query($sql)){
    die('Hay un error en la primera consulta!!! [' . $db->error . ']');
}      
   
echo "<option value=''>Seleccione:</option>";
  while($ro=$result->fetch_assoc()){
    $id=stripslashes($ro["id"]);
    $Nombre=stripslashes($ro["Nombre"]);
    echo "<option value='$id'>$Nombre</option>";
  }


////////////////////


       
    echo"</select><br><br>";
 
    echo"Cantidad en Paquete:<input name='Cantidad_en_Paquete' type='text'><br/>";
       echo"Cantidad de Paquete:<input name='   cantidad_de_paquetes' type='text'><br/>";
    echo"Fecha de ingreso:<input name='Fecha_Ingreso' type='date'><br/>";
    echo"Fecha de salida:<input name='Fecha_de_salida' type='date'><br/>";
    echo"<input type='submit' value='Registrar'><br/>";

    echo"</form>";
    echo"</center>";
?>

</body>
</html>