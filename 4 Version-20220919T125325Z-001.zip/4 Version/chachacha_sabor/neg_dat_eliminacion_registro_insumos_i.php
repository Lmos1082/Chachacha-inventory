<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body>
<?php
    include("baner.html");
   
  class Registro_de_insumos
  {
    public function eliminar_i_i($ID_Insumo)
    {
        include("conexion.php");

        mysqli_query($db,"DELETE FROM registro_insumos_inorganicos  WHERE ID_Insumo='$ID_Insumo'");

        header("Location: neg_dat_consultar_insu_inorganicos.php");

    }
  }
  $nuevo=new Registro_de_insumos();
  $nuevo->eliminar_i_i($_POST["ID_Insumo"]);
?>

</body>
</html>