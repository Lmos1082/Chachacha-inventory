<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body>
<?php

   

    class Menu_dia
    {
     
    public function actualizar()
    {
            include("conexion.php");
            echo"<table  aling='center'>";
           
$sql = "SELECT * FROM antaño WHERE precio='$precio'" ;
if(!$result = $db->query($sql)){
    die('Hay un error en la primera consulta!!! [' . $db->error . ']');
}    
    
    

  While($ro=$result->fetch_assoc()){
    $precio=stripslashes($ro["precio"]);
   
}
     echo"Descripcion actual: $precio <br/>";

   echo"<form name='actualizar' action='neg_dat_actualizacion_menu_a.php' method='POST' required >";
   echo"<input type='hidden' name='precio' value='$precio'>";
   echo"<input type='Submit' value='Actualizar'>";
   echo"</form>";


  }

}
    //termina la clase
$nuevo=new menu_dia();//Llamado a la clase
$nuevo->actualizar($_POST["Descripcion"]);
?>

</body>
</html>