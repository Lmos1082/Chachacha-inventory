<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body>
<?php
 
   

    class  Registro_de_insumos
    {
        public function registrar_i_i($Nombre,$categorias,$Cantidad_en_Paquete, $cantidad_de_paquetes,$Fecha_Ingreso, $Fecha_de_salida)
        {
           // echo "gdfgdfgdc";
            include("conexion.php");
            mysqli_query($db,"INSERT INTO  registro_insumos_inorganicos(ID_Insumo,Nombre,categorias,Cantidad_en_Paquete,cantidad_de_paquetes,Fecha_Ingreso,Fecha_de_salida) VALUES
             (NULL, '$Nombre','$categorias','$Cantidad_en_Paquete','$cantidad_de_paquetes','$Fecha_Ingreso','$Fecha_de_salida')");
            
            echo"Registro correcto";
            echo"<br/>";
            echo"<a href='pres_registro_insu_inorganicos.php'>Realizar nuevo registro</a>";



        }

    }
    $nuevo=new Registro_de_insumos();
    $nuevo->registrar_i_i($_POST["Nombre"],$_POST["categorias"],$_POST["Cantidad_en_Paquete"],$_POST["cantidad_de_paquetes"],$_POST["Fecha_Ingreso"],$_POST["Fecha_de_salida"]);
?>

</body>
</html>