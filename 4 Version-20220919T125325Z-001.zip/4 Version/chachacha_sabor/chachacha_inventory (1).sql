-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 08-09-2022 a las 19:05:53
-- Versión del servidor: 10.5.16-MariaDB
-- Versión de PHP: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `id19539711_chachacha_inventory`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

CREATE TABLE `administrador` (
  `numero_de_documento` int(10) NOT NULL,
  `tipo_de_documento` int(10) NOT NULL,
  `telefono` int(10) NOT NULL,
  `contraseña` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `Primer_Nombre` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `Segundo_Nombre` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `Primer_Apellido` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `Segundo_Apellido` varchar(10) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(16) NOT NULL,
  `Nombre` varchar(18) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `Nombre`) VALUES
(1, 'Lacteos'),
(2, 'Tapas'),
(3, 'Chocolates'),
(4, 'Bandejas'),
(5, 'Especias y harinas'),
(6, 'Cubiertos'),
(7, 'Frutas'),
(8, 'Copas o recipiente'),
(9, 'Merengues'),
(10, 'Bolsas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu`
--

CREATE TABLE `menu` (
  `id` int(16) NOT NULL,
  `nombre de producto` varchar(16) COLLATE utf8_spanish_ci NOT NULL,
  `precio` double NOT NULL,
  `producto` varchar(18) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_productos` int(18) NOT NULL,
  `nombre` varchar(15) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_productos`, `nombre`) VALUES
(1, 'Antaño'),
(2, 'Tortas'),
(3, 'Bebidas'),
(4, 'Merengones'),
(5, 'Chesecakes'),
(6, 'Obleas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_insumos_inorganicos`
--

CREATE TABLE `registro_insumos_inorganicos` (
  `ID_Insumo` int(5) NOT NULL,
  `Nombre` varchar(16) COLLATE utf8_spanish_ci NOT NULL,
  `categorias` varchar(19) COLLATE utf8_spanish_ci NOT NULL,
  `Cantidad_en_Paquete` int(5) NOT NULL,
  `cantidad_de_paquetes` varchar(16) COLLATE utf8_spanish_ci NOT NULL,
  `Fecha_Ingreso` date NOT NULL,
  `Fecha_de_salida` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `registro_insumos_inorganicos`
--

INSERT INTO `registro_insumos_inorganicos` (`ID_Insumo`, `Nombre`, `categorias`, `Cantidad_en_Paquete`, `cantidad_de_paquetes`, `Fecha_Ingreso`, `Fecha_de_salida`) VALUES
(1, 'tapas', '6', 19, '64', '2022-09-06', '2022-09-30'),
(2, 'Domos cuadrados', '6', 19, '16', '2022-09-27', '2022-09-30'),
(4, 'Bolsas de papel', '10', 19, '35', '2022-09-12', '2022-09-12'),
(5, 'tenedores', '8', 15, '29', '2022-09-28', '2022-09-30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_insumos_organicos`
--

CREATE TABLE `registro_insumos_organicos` (
  `ID_Insumo_O` int(5) NOT NULL,
  `Nombre_Insumo` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `Peso_Neto_en_paquete` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `Cantidad` int(5) NOT NULL,
  `Fecha_Ingreso` date NOT NULL,
  `Fecha_de_salida` date NOT NULL,
  `Categorias` varchar(11) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `registro_insumos_organicos`
--

INSERT INTO `registro_insumos_organicos` (`ID_Insumo_O`, `Nombre_Insumo`, `Peso_Neto_en_paquete`, `Cantidad`, `Fecha_Ingreso`, `Fecha_de_salida`, `Categorias`) VALUES
(5, 'sal', '1k', 6, '2022-09-07', '2022-09-22', '4');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reporte de insumos`
--

CREATE TABLE `reporte de insumos` (
  `id` int(11) NOT NULL,
  `Tipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`numero_de_documento`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_productos`);

--
-- Indices de la tabla `registro_insumos_inorganicos`
--
ALTER TABLE `registro_insumos_inorganicos`
  ADD PRIMARY KEY (`ID_Insumo`);

--
-- Indices de la tabla `registro_insumos_organicos`
--
ALTER TABLE `registro_insumos_organicos`
  ADD PRIMARY KEY (`ID_Insumo_O`);

--
-- Indices de la tabla `reporte de insumos`
--
ALTER TABLE `reporte de insumos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `registro_insumos_inorganicos`
--
ALTER TABLE `registro_insumos_inorganicos`
  MODIFY `ID_Insumo` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `registro_insumos_organicos`
--
ALTER TABLE `registro_insumos_organicos`
  MODIFY `ID_Insumo_O` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`id`) REFERENCES `administrador` (`numero_de_documento`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
