<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body>
<?php
    include("baner.html");
   

    class Menu_dia
    {
     
    public function actualizar($Descripcion, $precio)
    {
            include("conexion.php");
            mysqli_query($db, "UPDATE antaño SET precio='$precio' WHERE Descripcion='$Descripcion'");
           
echo "Actualizacion Correcta";
echo "<br/>";echo "<br/>";echo "<br/>";
    }
}//termina la clase
$nuevo=new menu_dia();//Llamado a la clase
$nuevo->actualizar($_POST["Descripcion"],$_POST["precio"]);
?>

</body>
</html>