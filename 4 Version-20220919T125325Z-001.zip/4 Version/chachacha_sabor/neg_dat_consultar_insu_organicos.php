<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body  >
<?php
    
  
    class Registro_de_insumos
    {
     
    public function consultar()
    {
            include("conexion.php");
           echo"<center>";
            echo"<h1>Insumos organicos:</h1>";
         
            echo"<table bgcolor='#000' width='1500' padding='0' height='100' boder-radious='50'>";
             echo"<hr>";
$sql = "SELECT * FROM registro_insumos_organicos";
if(!$result = $db->query($sql)){
    die('Hay un error en la primera consulta!!! [' . $db->error . ']');
}    
    
    echo"<tr bgcolor='#1A0439'>";
    echo"<td width='100'height='100'   >";echo"ID_Insumo_O"; echo"</td>"; 
     echo"<td width='170'>";echo"Nombre_Insumo"; echo"</td>"; echo"</td>";
     echo"<td width='170'>";echo"Peso_Neto_en_paquete";echo"</td>";
    echo"<td width='170' background='#7B066C'>";echo"Cantidad"; echo"</td>"; 
    echo"<td width='170'>";echo"Fecha_Ingreso"; echo"</td>"; 
    echo"<td width='180' background='#7B066C'>";echo"fecha de salida"; echo"</td>";
     echo"<td width='180'  background='#7B066C'>";echo"Categorias";echo"</td>";
   
     echo"<td width='180' background='#7B066C'>";echo"Accion"; echo"</td>";   
    echo"</tr>";
    echo"</br>";

  While($ro=$result->fetch_assoc()){
    $ID_Insumo_O=stripslashes($ro["ID_Insumo_O"]);
    $Nombre_Insumo=stripslashes($ro["Nombre_Insumo"]);
    $Peso_Neto_en_paquete=stripslashes($ro["Peso_Neto_en_paquete"]);
    $Cantidad=stripslashes($ro["Cantidad"]);
    $Fecha_Ingreso=stripslashes($ro["Fecha_Ingreso"]);
    $Fecha_de_salida=stripslashes($ro["Fecha_de_salida"]);
     $Categorias=stripslashes($ro["Categorias"]);
    echo"<tr>";
    echo"<td width='1000'>";echo"$ID_Insumo_O";echo"</td>";
    echo"<td width='1000'>";echo"$Nombre_Insumo";echo"</td>";
    echo"<td width='1000'>";echo"$Peso_Neto_en_paquete";echo"</td>";
    echo"<td width='1000'>";echo"$Cantidad";echo"</td>";
    echo"<td width='1000'>";echo"$Fecha_Ingreso";echo"</td>";
    echo"<td width='1000'>";echo"$Fecha_de_salida";echo"</td>";
   
   echo"<td width='1000'>";echo"$Categorias";echo"</td>";
    echo"<td>";
    echo"<form name='eliminar' method='POST' action='neg_dat_eliminacion_registro_insumos_o.php'>";
    echo"<input type='hidden' name='ID_Insumo_O' value='$ID_Insumo_O'>";
    echo"<input type='Submit' value='Eliminar'>";
    echo"</form>";
    echo"</td>";
    echo"<tr>";/*
    echo"<form name='actualiza' method='POST' action='pres_neg_dat_actulizacion_menu_a.php'>";
   echo"<input type='hidden' name='Descripcion' value='$Descripcion'>";
   echo"<input type='Submit' value='Actualizar'>";
   echo"</form>";
echo"</td>"; PONER FECHA DE SALIDA
*/
   echo"</tr>";
  }
echo"</table>";
echo"</center>";
}

    }//termina la clase
$nuevo=new Registro_de_insumos();//Llamado a la clase
$nuevo->consultar();


?>

</body>
</html>