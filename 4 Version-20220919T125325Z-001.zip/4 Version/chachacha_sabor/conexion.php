
<?php
header("content_type: text/html;charset=utf-8");
$db =new mysqli('localhost','root','','chachacha_inventor');
$acentos = $db-> query("SET NAMES 'utf8'");
if ($db->connect_error > 0){
    die('Error de conexion[' . $db->connect_error .']');
  
}
?>

