
  <?php
      include_once'conexion.php';
  ?>

<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="estilos_formularios.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body bgcolor="#000">


   <center>
    <h1>Registre el insumo organico<h1>
 <br>
  <br>
  <br>
  <br>
  
    <br>
  <br>
   <form name="registro_menu" action="neg_dat_registro_insu_organicos.php" method="POST" required>
    <label>Nombre:</label>
   <input name="Nombre_Insumo" type="text"><br/>
   <label>Peso neto en paquete:</label>
<input name="Peso_Neto_en_paquete" type="text"><br/>
<label>Cantidad de unidades:</label>
  <input name="Cantidad" type="text"><br/>
  <label>Fecha de ingreso:</label>
  <input name="Fecha_Ingreso" type="date"><br/>
  <label>Fecha de Salida :</label>
  <input name="Fecha_de_salida" type="date"><br/>  
  <label>Categoria:</label>
  <select name="Categorias" required="required">
   <?php
   /////////////
   include("conexion.php");

   $sql = "SELECT * FROM categorias";
if(!$result = $db->query($sql)){
    die('Hay un error en la primera consulta!!! [' . $db->error . ']');
}      
   
echo "<option value=''>Seleccione:</option>";
  while($ro=$result->fetch_assoc()){
    $id=stripslashes($ro["id"]);
    $Nombre=stripslashes($ro["Nombre"]);
    echo "<option value='$id'>$Nombre</option>";
  }


////////////////////
   ?>


         
</select><br><br>
<input type="submit" value="Registrar"></input>

  </form>
</center>


</body>
</html>