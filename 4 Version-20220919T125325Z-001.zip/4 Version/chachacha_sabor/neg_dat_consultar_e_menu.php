<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body bgcolor="#e383f0" >
<?php
    include("neg_dat_consultar_e_menu_m.php");

    

    class Menu_dia
    {
     
    public function consultar()
    {
            include("conexion.php");
           
            
            echo"<h1>Antaño</h1>";
            echo"<center>";
            echo"<table background='arroz-con-leche.jpg'  width='750' height='100' >";
            echo"</center>";
$sql = "SELECT * FROM antaño";
if(!$result = $db->query($sql)){
    die('Hay un error en la primera consulta!!! [' . $db->error . ']');
}    
    
    echo"<tr background-color= '#dd90dd4f'>";
    echo"<td width='90'height='100'>";echo"Descripcion"; echo"</td>";  echo"<td width='170'>";echo"precio"; echo"</td>";    echo"<td width='180'>";echo"Eliminar"; echo"</td>"; echo"<td width='180'>";echo"Accion"; echo"</td>";
    echo"</tr>";

  While($ro=$result->fetch_assoc()){
    $Descripcion=stripslashes($ro["Descripcion"]);
    $precio=stripslashes($ro["precio"]);

    echo"<tr background-color= '#dd90dd4f'>";
    echo"<td width='1000'>";echo"$Descripcion";echo"</td>";
    echo"<td>";echo"$precio";echo"</td>";
    
    echo"<td>";
    echo"<form name='eliminar' method='POST' action='neg_dat_eliminacion_menu.php'>";
    echo"<input type='hidden' name='Descripcion' value='$Descripcion'>";
    echo"<input type='Submit' value='Eliminar'>";
    echo"</form>";
    echo"</td>";
    echo"<td>";/*
    echo"<form name='actualiza' method='POST' action='pres_neg_dat_actulizacion_menu_a.php'>";
   echo"<input type='hidden' name='Descripcion' value='$Descripcion'>";
   echo"<input type='Submit' value='Actualizar'>";
   echo"</form>";
echo"</td>";
*/
   echo"</tr>";
  }
echo"</table>";

}

    }//termina la clase
$nuevo=new menu_dia();//Llamado a la clase
$nuevo->consultar();

include("neg_dat_consultar_e_menu_t.php");
include("neg_dat_consultar_e_menu_o.php");
include("neg_dat_consultar_e_menu_b.php");



?>

</body>
</html>