<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body>
<?php
    include("baner.html");
   
  class menu_dia
  {
    public function eliminar($Descripcion)
    {
        include("conexion.php");

        mysqli_query($db,"DELETE FROM antaño WHERE Descripcion='$Descripcion'");

        header("Location: neg_dat_consultar_e_menu.php");

    }
  }
  $nuevo=new menu_dia();
  $nuevo->eliminar($_POST["Descripcion"]);
?>

</body>
</html>