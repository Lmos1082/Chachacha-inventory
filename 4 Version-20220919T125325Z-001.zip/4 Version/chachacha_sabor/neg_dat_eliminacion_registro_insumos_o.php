<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body>
<?php
    include("baner.html");
   
  class Registro_de_insumos
  {
    public function eliminar_i_o($ID_Insumo_O)
    {
        include("conexion.php");

        mysqli_query($db,"DELETE FROM registro_insumos_organicos  WHERE ID_Insumo_O='$ID_Insumo_O'");

        header("Location: neg_dat_consultar_insu_organicos.php");

    }
  }
  $nuevo=new Registro_de_insumos();
  $nuevo->eliminar_i_o($_POST["ID_Insumo_O"]);
?>

</body>
</html>