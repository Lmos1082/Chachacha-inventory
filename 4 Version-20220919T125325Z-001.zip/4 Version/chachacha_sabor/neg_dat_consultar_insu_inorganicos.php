<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body  >
<?php
    
  
    class Registro_de_insumos
    {
     
    public function consultar()
    {
            include("conexion.php");
            echo"<center>";
            echo"<h1>Insumos Inorganicos:</h1>";
          
            echo"<table bgcolor='#000' width='1500' padding='0' height='100' >";
           
$sql = "SELECT * FROM registro_insumos_inorganicos";
if(!$result = $db->query($sql)){
    die('Hay un error en la primera consulta!!! [' . $db->error . ']');
}    
    
    echo"<tr bgcolor='#043939'>";
    echo"<td width='100'height='100'   >";echo"ID_Insumo"; echo"</td>"; 
     echo"<td width='170'>";echo"Nombre"; echo"</td>"; echo"</td>";
     echo"<td width='170'  background='#7B066C'>";echo"categorias";echo"</td>";
    
    echo"<td width='170' background='#7B066C'>";echo"Cantidad_en_Paquete"; echo"</td>";
     echo"<td width='170'>";echo"cantidad_de_paquetes";echo"</td>"; 
    echo"<td width='170'>";echo"Fecha_Ingreso"; echo"</td>"; 
    echo"<td width='180' background='#7B066C'>";echo"Fecha_de_salida"; echo"</td>";
     echo"<td width='180' background='#7B066C'>";echo"Accion"; echo"</td>";   
    echo"</tr>";
    echo"</br>";
    echo"<hr>";

  While($ro=$result->fetch_assoc()){
    $ID_Insumo=stripslashes($ro["ID_Insumo"]);
    $Nombre=stripslashes($ro["Nombre"]);
    $categorias=stripslashes($ro["categorias"]);
    $Cantidad_en_Paquete=stripslashes($ro["Cantidad_en_Paquete"]);
    $cantidad_de_paquetes=stripslashes($ro["cantidad_de_paquetes"]);
    $Fecha_Ingreso=stripslashes($ro["Fecha_Ingreso"]);
    $Fecha_de_salida=stripslashes($ro["Fecha_de_salida"]);
    
    echo"<tr>";
    echo"<td width='1000'>";echo"$ID_Insumo";echo"</td>";
    echo"<td width='1000'>";echo"$Nombre";echo"</td>";
    echo"<td width='1000'>";echo"$categorias";echo"</td>";
   
    echo"<td width='1000'>";echo"$Cantidad_en_Paquete";echo"</td>";
     echo"<td width='1000'>";echo"$cantidad_de_paquetes";echo"</td>";
    echo"<td width='1080'>";echo"$Fecha_Ingreso";echo"</td>";
    echo"<td width='1080'>";echo"$Fecha_de_salida";echo"</td>";
    echo"<td>";
    echo"<form name='eliminar' method='POST' action='neg_dat_eliminacion_registro_insumos_i.php'>";
    echo"<input type='hidden' name='ID_Insumo' value='$ID_Insumo'>";
    echo"<input type='Submit' value='eliminar' background='borrar-.png'";
   
    echo"</form>";
    echo"</td>";
    /*echo"<td>";
    echo"<form name='actualiza' method='POST' action='pres_neg_dat_actulizacion_menu_a.php'>";
   echo"<input type='hidden' name='Descripcion' value='$Descripcion'>";
   echo"<input type='Submit' value='Actualizar'>"; >
   echo"</form>";
echo"</td>"; PONER FECHA DE SALIDA
*/
   echo"</tr>";
  }
echo"</table>";
echo"</center>";
}

    }//termina la clase
$nuevo=new Registro_de_insumos();//Llamado a la clase
$nuevo->consultar();


?>

</body>
</html>