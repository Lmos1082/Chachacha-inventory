<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body>
<?php
  
    echo"<center>";
    echo"<h1>Registre su el postre de antaño<h1>";
    echo"<form name='registro_menu' action='neg_dat_registro_menu_a.php' method='POST' required>";
    echo"Descripcion:<input name='Descripcion' type='text'><br/>";
    echo"Precio:<input name='precio' type='text'><br/>";
    echo"<input type='submit' value='Registrar'><br/>";

    echo"</form>";
    echo"</center>";
?>

</body>
</html>