<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body>
<?php
 
   

    class  Registro_de_insumos
    {
        public function registrar_i($Nombre_Insumo,$Peso_Neto_en_paquete,$Cantidad,$Fecha_Ingreso,$Fecha_de_salida,$Categorias)
        {
            include("conexion.php");
            mysqli_query($db,"INSERT INTO  registro_insumos_organicos ( ID_Insumo_O,Nombre_Insumo,Peso_Neto_en_paquete,Cantidad,Fecha_Ingreso,Fecha_de_salida,Categorias) VALUES
             (NULL, '$Nombre_Insumo','$Peso_Neto_en_paquete','$Cantidad','$Fecha_Ingreso','$Fecha_de_salida','$Categorias')");
            
            echo"Registro correcto";
            echo"<br/>";
            echo"<a href='pres_registro_insu_organicos.php'>Realizar nuevo registro</a>";



        }

    }
    $nuevo=new Registro_de_insumos();
    $nuevo->registrar_i($_POST["Nombre_Insumo"],$_POST["Peso_Neto_en_paquete"],$_POST["Cantidad"],$_POST["Fecha_Ingreso"],$_POST["Fecha_de_salida"],$_POST["Categorias"]);
?>

</body>
</html>