<html>
<head> 
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body>
<?php
    include("baner.html");
   

    class  Menu_dia
    {
        public function registrar_a($descripcion, $precio)
        {
            include("conexion.php");
            mysqli_query($db,"INSERT INTO antaño(id,Descripcion,precio) VALUES (NULL,'$descripcion','$precio')");
            
            echo"Registro correcto";
            echo"<br/>";
            echo"<a href='pres_registro_menu_a.php'>Realizar nuevo registro</a>";



        }

    }
    $nuevo=new menu_dia();
    $nuevo->registrar_a($_POST["Descripcion"],$_POST["precio"]);
?>

</body>
</html>