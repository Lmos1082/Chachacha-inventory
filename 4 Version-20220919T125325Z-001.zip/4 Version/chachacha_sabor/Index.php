<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 
<head> 
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <title>Chachacha inventory</title>
    <link href="admin.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="log0.png">

</head>
<body bgcolor="#000" height="8500">
    <?php
    include("baner.html");
    include("contenido.html");
    
    ?>
<body>
</html>